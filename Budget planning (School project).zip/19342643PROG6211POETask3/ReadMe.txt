To execute the application double click on the file named:
	19342643PROG6211POETask3.exe
To view the code and design of the whole project click on the file named:
	19342643PROG6211POETask3.sln

This is a school project built using Windows Presentation Foundation (WPF) and C#
