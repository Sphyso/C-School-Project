﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _19342643PROG6211POETask3
{
    /// <summary>
    /// Interaction logic for RentPage.xaml
    /// </summary>
    public partial class RentPage : Window
    {
        
        public RentPage()
        {
            InitializeComponent();
        }
       // delegate declaration 
        public delegate void over75Alert(string message);
        public static void displayMessage(string message)
        {
            MessageBox.Show(message);
        }
        //Calls expense report 
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Rent robj = new Rent();
            Report repobj = new Report();
            //assigns values and handels exceptions.
            try
            {
                double monthlyRent = double.Parse(monthlyRentBox.Text);
                robj.userInput(monthlyRent, 0, 0, 0);

                repobj.RMonthlyRentBox.Text = robj.MonthlyRent.ToString();
                repobj.AmountLeftBox.Text = robj.moneyLeft().ToString();

                robj.totalExpenses();
                double checkValue = robj.MonthlyIncome * 0.75;

                //Check if expenses are over 75%
                if (robj.totalExpenses() > checkValue)
                {
                    over75Alert over = new over75Alert(displayMessage);
                    over("Your Expenses are over 75% of your income, I encourage you to reconsider your budget.");
                }
                repobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                monthlyRentBox.Clear();
            }
        }
        //Calls vehiclepage
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            VehiclePage vpobj = new VehiclePage();
            Rent robj = new Rent();
            Report repobj = new Report();
            //assigns values and handels exceptions.
            try
            {
                double monthlyRent = double.Parse(monthlyRentBox.Text);
                robj.userInput(monthlyRent, 0, 0, 0);

                repobj.RMonthlyRentBox.Text = robj.MonthlyRent.ToString();
                repobj.AmountLeftBox.Text = robj.moneyLeft().ToString();

                vpobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                monthlyRentBox.Clear();
            }
        }
    }
}
