﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    abstract class Expense
    {
        //Variable needed for the program
        private static double monthlyRent;
        //Variables for home loan
        private static double priceProperty;
        private static double totalDeposit;
        private static double interestRate;
        private static double monthsToRepay;
        private static double totalRepayment;
        private static double monthlyRepayment;
        //Variables for Vehicle
        private static double purchasePrice;
        private static double totalDepositV;
        private static double interestRateV;
        private static double premium;
        private static string model;
        private static string make;
        private static double monthlyIncome;
        private static double taxDeductions;
        //Variables for Savings
        private static double goalAmount;
        private static double years;
        private static double interestRateS;


        public static double expenseTotal = 0;
        //Properties used to access private data fields
        public double MonthlyRent
        {
            get { return monthlyRent; }
            set { monthlyRent = value; }
        }
        public double PriceProperty
        {
            get { return priceProperty; }
            set { priceProperty = value; }
        }
        public double TotalDeposit
        {
            get { return totalDeposit; }
            set { totalDeposit = value; }
        }
        public double InterestRate
        {
            get { return interestRate; }
            set { interestRate = value; }
        }
        public double MonthsToRepay
        {
            get { return monthsToRepay; }
            set { monthsToRepay = value; }
        }
        public double TotalRepayment
        {
            get { return totalRepayment; }
            set { totalRepayment = value; }
        }
        public double MonthlyRepayment
        {
            get { return monthlyRepayment; }
            set { monthlyRepayment = value; }
        }
        public double MonthlyIncome
        {
            get { return monthlyIncome; }
            set { monthlyIncome = value; }
        }
        public double TaxDeductions
        {
            get { return taxDeductions; }
            set { taxDeductions = value; }
        }
        public double PurchasePrice
        {
            get { return purchasePrice; }
            set { purchasePrice = value; }
        }
        public double TotalDepositV
        {
            get { return totalDepositV; }
            set { totalDepositV = value; }
        }
        public double InterestRateV
        {
            get { return interestRateV; }
            set { interestRateV = value; }
        }
        public double Premium
        {
            get { return premium; }
            set { premium = value; }
        }
        public string Model
        {
            get { return model; }
            set { model = value; }
        }
        public string Make
        {
            get { return make; }
            set { make = value; }
        }
        public double GoalAmount 
        { 
            get { return goalAmount; }
            set {goalAmount = value; } 
        }
        public double Years
        {
            get { return years; }
            set { years = value; }
        }
        public double InterestRateS
        {
            get { return interestRateS; }
            set { interestRateS  = value; }
        }

        //Method that are implemented in other classes
        public abstract void Expenditure(double g, double w, double t, double p, double o);
        public abstract void userInput(double n, double a, double b, double c);
        public abstract double total_Repayment();
        public abstract double monthly_Repayment();
        public abstract void check();
        public abstract double moneyLeft();

    }
}
