﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class HomeLoan : Expense
    {
        PropertyPage ppobj = new PropertyPage();
        public override void check()
        {
            throw new NotImplementedException();
        }

        public override void Expenditure(double g, double w, double t, double p, double o)
        {
            throw new NotImplementedException();
        }
        //Calculates amount left after all deductions
        public override double moneyLeft()
        {
            double remaingAmount;

            remaingAmount = MonthlyIncome - (TaxDeductions + expenseTotal + monthly_Repayment());
            remaingAmount = Math.Round(remaingAmount, 2);

            return remaingAmount;
        }
        //Calculates total of expenses
        public double totalExpenses()
        {
            double totalExpenses = TaxDeductions + expenseTotal + monthly_Repayment();
            return totalExpenses;
        }
        //Calculates monthly repayment
        public override double monthly_Repayment()
        {
            MonthlyRepayment = total_Repayment() / MonthsToRepay;
            MonthlyRepayment = Math.Round(MonthlyRepayment, 2);
            return MonthlyRepayment;
        }
        //Calculates total repayment
        public override double total_Repayment()
        {
            double rate = InterestRate / 100;
            double principalAmount = PriceProperty - TotalDeposit;
            double timeYears = MonthsToRepay / 12;

            TotalRepayment = principalAmount * (1 + rate * timeYears);
            TotalRepayment = Math.Round(TotalRepayment, 2);
            return TotalRepayment;
        }
        //Receives values from Propertypage
        public override void userInput(double n, double a, double b, double c)
        {

            PriceProperty = n;
            TotalDeposit = a;
            InterestRate = b;
            MonthsToRepay = c;

        }
    }
}
