﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class Savings : Expense
    {
        public override void check()
        {
            throw new NotImplementedException();
        }

        public override void Expenditure(double g, double w, double t, double p, double o)
        {
            throw new NotImplementedException();
        }

        public override double moneyLeft()
        {
            throw new NotImplementedException();
        }

        public override double monthly_Repayment()
        {
            double monthlySavings;
            double rate = InterestRateS / 100;
            double n = 12;
            double months = n * Years;
            double bracketCal = 1 + rate / n;

            monthlySavings = GoalAmount * ((rate / n) / (Math.Pow(bracketCal, months) - 1));

            monthlySavings = Math.Round(monthlySavings, 2);

            return monthlySavings;

        }

        public override double total_Repayment()
        {
            throw new NotImplementedException();
        }

        public override void userInput(double n, double a, double b, double c)
        {
            GoalAmount = n;
            Years = a;
            InterestRateS = b;
        }
    }
}
