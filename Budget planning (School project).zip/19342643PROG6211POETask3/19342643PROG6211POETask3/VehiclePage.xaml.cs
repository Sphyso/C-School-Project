﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _19342643PROG6211POETask3
{
    /// <summary>
    /// Interaction logic for VehiclePage.xaml
    /// </summary>
    public partial class VehiclePage : Window
    {
        public VehiclePage()
        {
            InitializeComponent();
        }
        //declares delegates
        public delegate void over75Alert(string message);
        public static void displayMessage(string message)
        {
            MessageBox.Show(message);
        }
        //Calls the report page
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Vehicle vobj = new Vehicle();
            Report repobj = new Report();
            Rent robj = new Rent();
            HomeLoan hlobj = new HomeLoan();
            //assigns values and handles exceptions
            try
            {
                string make = makeBox.Text.ToString();
                string model = modelBox.Text.ToString();
                double price = double.Parse(carPriceBox.Text);
                double deposit = double.Parse(depostitBox.Text);
                double rate = double.Parse(interestRateBox.Text);
                double premium = double.Parse(premiumBox.Text);

                vobj.userInput(price, deposit, rate, premium);
                vobj.user(make, model);

                repobj.VTotalRepayBox.Text = vobj.total_Repayment().ToString();
                repobj.VMonthlyRepayBox.Text = vobj.monthly_Repayment().ToString();
                repobj.RMonthlyRentBox.Text = vobj.MonthlyRent.ToString();
                repobj.PTotalRepayBox.Text = hlobj.total_Repayment().ToString();
                repobj.PMonthlyRepayBox.Text = hlobj.monthly_Repayment().ToString();
                repobj.AmountLeftBox.Text = vobj.moneyLeft().ToString();

                vobj.totalExpenses();
                double checkValue = vobj.MonthlyIncome * 0.75;

                //Check if expenses are over 75%
                if (vobj.totalExpenses() > checkValue)
                {
                    over75Alert over = new over75Alert(displayMessage);
                    over("Your Expenses are over 75% of your income, Please your to reconsider your budget.");
                }

                repobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                makeBox.Clear();
                modelBox.Clear();
                carPriceBox.Clear();
                depostitBox.Clear();
                interestRateBox.Clear();
                premiumBox.Clear();
            }
        }
    }
}
