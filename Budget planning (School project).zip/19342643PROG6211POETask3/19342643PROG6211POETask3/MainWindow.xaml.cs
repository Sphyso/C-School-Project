﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _19342643PROG6211POETask3
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        //Button that calls Property Page
        private void purchaseHouse_Click(object sender, RoutedEventArgs e)
        {
            PropertyPage ppobj = new PropertyPage();
            Program pobj = new Program();
            Savings sobj = new Savings();
            Report repobj = new Report();
            //Handles errors for expenses, monthly income and tax deduction
            try
            {
                double monthlyIncome = double.Parse(monthlyIncomeBox.Text);
                double taxDeductions = double.Parse(taxDeductionBox.Text);

                pobj.userInput(monthlyIncome, taxDeductions, 0, 0);
                
                ppobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                monthlyIncomeBox.Clear();
                taxDeductionBox.Clear();
            }

            try
            {
                double grocries = double.Parse(groceriesBox.Text);
                double water = double.Parse(waterBox.Text);
                double travel = double.Parse(travelBox.Text);
                double phone = double.Parse(phoneBox.Text);
                double other = double.Parse(otherBox.Text);

                pobj.Expenditure(grocries, water, travel, phone, other);
                
                ppobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                groceriesBox.Clear();
                waterBox.Clear();
                travelBox.Clear();
                phoneBox.Clear();
                otherBox.Clear();
            }

        }
        //Button Calls Rent page
        private void rent_Click(object sender, RoutedEventArgs e)
        {
            RentPage rpobj = new RentPage();
            Program pobj = new Program();
            Report repobj = new Report();
            Savings sobj = new Savings();
            //Handles errors for expenses, monthly income and tax deduction
            Expenditure<double> expbj = new Expenditure<double>();
            try
            {
                double monthlyIncome = double.Parse(monthlyIncomeBox.Text);
                double taxDeductions = double.Parse(taxDeductionBox.Text);

                pobj.userInput(monthlyIncome, taxDeductions, 0, 0);
                
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                monthlyIncomeBox.Clear();
                taxDeductionBox.Clear();
            }

            try
            {
                double grocries = double.Parse(groceriesBox.Text);
                double water = double.Parse(waterBox.Text);
                double travel = double.Parse(travelBox.Text);
                double phone = double.Parse(phoneBox.Text);
                double other = double.Parse(otherBox.Text);

                pobj.Expenditure(grocries, water, travel, phone, other);
                pobj.displayExpense();
                rpobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                groceriesBox.Clear();
                waterBox.Clear();
                travelBox.Clear();
                phoneBox.Clear();
                otherBox.Clear();
            }
            

        }
        //Button for savings plan
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Savings sobj = new Savings();
            //Assigns values and handles errors
            try
            {
                double goalAmount = double.Parse(goalAmountBox.Text);
                double years = double.Parse(timeBox.Text);
                double interestRate = double.Parse(interestRateBox.Text);

                sobj.userInput(goalAmount, years, interestRate, 0);

                displaySaving.Text = sobj.monthly_Repayment().ToString();
                

            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include percentage sign.");
                goalAmountBox.Clear();
                timeBox.Clear();
                interestRateBox.Clear();   
            }
  
        }
    }
}
