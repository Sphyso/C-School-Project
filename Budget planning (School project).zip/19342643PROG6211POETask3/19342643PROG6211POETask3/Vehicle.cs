﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class Vehicle : Expense
    {
        HomeLoan hlobj = new HomeLoan();
        public override void check()
        {
            throw new NotImplementedException();
        }

        public override void Expenditure(double g, double w, double t, double p, double o)
        {
            throw new NotImplementedException();
        }
        //Calculate money left after deductions
        public override double moneyLeft()
        {
            double remaingAmount;
            if(hlobj.total_Repayment() != 0)
            {
                remaingAmount = MonthlyIncome - (TaxDeductions + expenseTotal + MonthlyRent + monthly_Repayment() + hlobj.monthly_Repayment());
            }
            else
            {
                remaingAmount = MonthlyIncome - (TaxDeductions + expenseTotal + MonthlyRent + monthly_Repayment());
            }
            return remaingAmount;
        }
        //Calculate total expenses
        public double totalExpenses()
        {
            double totalExpenses;
            if (hlobj.total_Repayment() != 0)
            {
                totalExpenses = TaxDeductions + expenseTotal + MonthlyRent + monthly_Repayment() + hlobj.monthly_Repayment();
            }
            else
            {
                totalExpenses = TaxDeductions + expenseTotal + MonthlyRent + monthly_Repayment();
            }
            return totalExpenses;
        }
        //Calculate monthly repay
        public override double monthly_Repayment()
        {
            double monthlyRepayment;

            monthlyRepayment = (total_Repayment() / 60) + Premium;
            monthlyRepayment = Math.Round(monthlyRepayment, 2);

            return monthlyRepayment;
        }
        //Calculate total repay
        public override double total_Repayment()
        {
            double rate = InterestRateV / 100;
            double years = 5;
            double repaymentTotal;
            double price = PurchasePrice - TotalDepositV;

            repaymentTotal = price * (1 + rate * years);
            repaymentTotal = Math.Round(repaymentTotal, 2);

            return repaymentTotal;
        }
        //gets values from VehiclePage
        public override void userInput(double n, double a, double b, double c)
        {

            
            PurchasePrice = n;
            TotalDepositV = a;
            InterestRateV = b;
            Premium = c;

        } 

        public void user(string m, string g)
        {
            Make = m;
            Model = g;
        }
    }
}
