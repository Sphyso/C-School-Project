﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class Expenditure<T> : IExpenditure<T>
    {
        //Objects for lists.
        List<T> expList = new List<T>();
        List<T> itemList = new List<T>();
        //methods to store values
        public void additemName(T value)
        {
            itemList.Add(value);
        }
        public void addValue(T value)
        {
            expList.Add(value);
        }
        //methods to get all list values
        public List<T> GetItems()
        {
            return itemList;
        }
        public List<T> GetValues()
        {
            return expList;
        }
    }
}
