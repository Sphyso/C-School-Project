﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    interface IExpenditure<T>
    {
        //Declaring methods that will store expense values
        void addValue(T value);
        void additemName(T value);
        List<T> GetItems();
        List<T> GetValues();
    }
}
