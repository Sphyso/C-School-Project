﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class Program : Expense
    {
        MainWindow mwobj = new MainWindow();
        Report repobj = new Report();
        //Object used to get the expense values and expense item
        static Expenditure<string> ex_pbj = new Expenditure<string>();
        static Expenditure<double> expbj = new Expenditure<double>();
        public override void check()
        {
            throw new NotImplementedException();
        }

        public override void Expenditure(double g, double w, double t, double p, double o)
        {
            ex_pbj.additemName("Groceries");
            ex_pbj.additemName("Water and Lights");
            ex_pbj.additemName("Travel Costs");
            ex_pbj.additemName("Phones");
            ex_pbj.additemName("Other");

            expbj.addValue(g);
            expbj.addValue(w);
            expbj.addValue(t);
            expbj.addValue(p);
            expbj.addValue(o);

            expenseTotal = expbj.GetValues().Sum();
        }
        public void displayExpense()
        {
            expbj.GetValues().Sort();
            expbj.GetValues().Reverse();

            foreach (var item in expbj.GetValues())
            {
                
            }
        }
        public override double moneyLeft()
        {
            return expenseTotal;
        }

        public override double monthly_Repayment()
        {
            throw new NotImplementedException();
        }

        public override double total_Repayment()
        {
            throw new NotImplementedException();
        }

        public override void userInput(double n, double a, double b, double c)
        {
            MonthlyIncome = n;
            TaxDeductions = a;
        }
    }
}
