﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace _19342643PROG6211POETask3
{
    /// <summary>
    /// Interaction logic for PropertyPage.xaml
    /// </summary>
    public partial class PropertyPage : Window
    {
        static Expenditure<string> ex_pbj = new Expenditure<string>();
        static Expenditure<double> expbj = new Expenditure<double>();
        MainWindow mwobj = new MainWindow();
        public PropertyPage()
        {
            InitializeComponent();
        }
        //Delegate declaration
        public delegate void over75Alert(string message);
        public static void displayMessage(string message)
        {
            MessageBox.Show(message);
        }
        //Button call the Report and display results
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            HomeLoan hlobj = new HomeLoan();
            Report repobj = new Report();
            //Declares variables and handles errors
            try
            {
                double propertyPrice = double.Parse(propertyPriceBox.Text);
                double interestRate = double.Parse(interestRateBox.Text);
                double totalDeposit = double.Parse(totalDepositBox.Text);
                

                while (double.Parse(noOfMonthsBox.Text) < 240 || double.Parse(noOfMonthsBox.Text) > 360)
                {
                    double.Parse(noOfMonthsBox.Text);
                    noOfMonthsBox.Clear();
                }
                double NoofMonths = double.Parse(noOfMonthsBox.Text);
                hlobj.userInput(propertyPrice, totalDeposit, interestRate, NoofMonths);
                repobj.PTotalRepayBox.Text = hlobj.total_Repayment().ToString();
                repobj.PMonthlyRepayBox.Text = hlobj.monthly_Repayment().ToString();
                repobj.AmountLeftBox.Text = hlobj.moneyLeft().ToString();
                //Check monthly repayment is over one third of monthly income
                double loanCheck = hlobj.MonthlyIncome / 3;
                if (hlobj.monthly_Repayment() > loanCheck)
                {
                    MessageBox.Show("Sorry but the monthly repayment is more than one third of your income.");
                }
                hlobj.totalExpenses();
                double checkValue = hlobj.MonthlyIncome * 0.75;

                //Check if expenses are over 75%
                if (hlobj.totalExpenses() > checkValue)
                {
                    over75Alert over = new over75Alert(displayMessage);
                    over("Your Expenses are over 75% of your income, Please your to reconsider your budget.");
                }

                repobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include " +
                    "percentage sign. Make sure months are between (240 - 360)");
                propertyPriceBox.Clear();
                totalDepositBox.Clear();
                interestRateBox.Clear();
                noOfMonthsBox.Clear();
            }
            
        }
        //Button call Vehicle page
        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            VehiclePage vpobj = new VehiclePage();
            HomeLoan hlobj = new HomeLoan();
            Report repobj = new Report();
            //Assigns variables and handles errors
            try
            {
                double propertyPrice = double.Parse(propertyPriceBox.Text);
                double totalDeposit = double.Parse(totalDepositBox.Text);
                double interestRate = double.Parse(interestRateBox.Text);
                while (double.Parse(noOfMonthsBox.Text) < 240 || double.Parse(noOfMonthsBox.Text) > 360)
                {
                    double.Parse(noOfMonthsBox.Text);
                    noOfMonthsBox.Clear();
                }
                double NoofMonths = double.Parse(noOfMonthsBox.Text);
                hlobj.userInput(propertyPrice, totalDeposit, interestRate, NoofMonths);

                repobj.PTotalRepayBox.Text = hlobj.total_Repayment().ToString();
                repobj.PMonthlyRepayBox.Text = hlobj.monthly_Repayment().ToString();
                repobj.AmountLeftBox.Text = hlobj.moneyLeft().ToString();
                //Check monthly repayment is over one third of monthly income
                double loanCheck = hlobj.MonthlyIncome / 3;
                if (hlobj.monthly_Repayment() > loanCheck)
                {
                    MessageBox.Show("Sorry but the monthly repayment is more than one third of your income.");
                }

                vpobj.Show();
                this.Hide();
            }
            catch (Exception)
            {
                MessageBox.Show("Please enter values only, no unnecessary spaces, use a comma for decimals and do not include " +
                    "percentage sign. Make sure months are between (240 - 360)");
                propertyPriceBox.Clear();
                totalDepositBox.Clear();
                interestRateBox.Clear();
                noOfMonthsBox.Clear();
            }
  
        }
    }
}
