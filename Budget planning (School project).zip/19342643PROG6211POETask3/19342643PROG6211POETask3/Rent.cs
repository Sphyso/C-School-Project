﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _19342643PROG6211POETask3
{
    class Rent : Expense
    {
        Vehicle vobj = new Vehicle();
        public override void check()
        {
            throw new NotImplementedException();
        }

        public override void Expenditure(double g, double w, double t, double p, double o)
        {
            
        }
        //Calculates money left after deductions
        public override double moneyLeft()
        {
            double remaingAmount;

            remaingAmount = MonthlyIncome - (TaxDeductions + expenseTotal + MonthlyRent + vobj.monthly_Repayment());

            return remaingAmount;
        }
        //calculate total expenses
        public double totalExpenses()
        {
            double totalExpenses = TaxDeductions + expenseTotal + MonthlyRent;
            return totalExpenses;
        }

        public override double monthly_Repayment()
        {
            throw new NotImplementedException();
        }

        public override double total_Repayment()
        {
            throw new NotImplementedException();
        }
        //Recieves value from RentPage
        public override void userInput(double n, double a, double b, double c)
        {

            MonthlyRent = n;
                
        }
    }
}
